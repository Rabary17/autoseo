import { getAllPosts } from "@/lib/posts";

// Accueil = texte de présentation (rédigé le 2026-09-30, sert aussi de
// brief de contenu pour la charte graphique à venir) + listing du blog en
// dessous. Pas de pagination pour l'instant (volume visé trop faible pour
// en avoir besoin) — à ajouter le jour où la liste dépasse une trentaine
// d'articles, sur le même principe que app/categorie/[slug]/page.tsx sur
// monauto/Techcars.
const CATEGORIES = [
  {
    title: "Technologie & gadgets",
    body: "Smartphones, ordinateurs, objets connectés, audio, domotique : cette catégorie couvre le matériel et les services que vous utilisez — ou envisagez d'acheter — au quotidien. On y trouve des tests pratiques, des comparatifs honnêtes entre plusieurs produits, et des explications sur ce qui rend un appareil réellement meilleur qu'un autre, au-delà de la fiche technique marketing. L'idée n'est pas de vous pousser vers le produit le plus cher, mais vers celui qui correspond réellement à votre usage et à votre budget. On y retrouve aussi des guides d'achat saisonniers et des dossiers sur les tendances qui durent — comme la domotique ou l'écoconception — face à celles qui ne sont, pour l'instant, que des effets d'annonce.",
  },
  {
    title: "Jeux vidéo & gaming",
    body: "Sorties attendues, tests de jeux, actualité de l'esport, matériel gaming (cartes graphiques, PC, périphériques) : la catégorie Jeux couvre le jeu vidéo comme loisir et comme industrie. On y parle aussi bien des grosses productions que des jeux indépendants qui méritent d'être découverts, et des évolutions techniques — moteurs de jeu, cloud gaming — qui redessinent la façon de jouer (la réalité virtuelle a sa propre catégorie, juste à côté). On y aborde aussi les choix de configuration pour jouer dans de bonnes conditions sans se ruiner, et les tendances qui traversent la communauté : abonnements, jeux-services, montée en puissance du jeu mobile.",
  },
  {
    title: "Réalité virtuelle & réalité augmentée",
    body: "Réalité virtuelle, réalité augmentée, réalité mixte : cette catégorie couvre le matériel — casques, lunettes connectées — et les usages, bien au-delà du seul jeu vidéo : formation professionnelle, santé, visite virtuelle, collaboration à distance. On y teste les casques et applications qui comptent vraiment, on explique les différences entre des technologies souvent confondues (VR, AR, XR), et on prend du recul sur les promesses répétées d'un « métavers » qui peine encore à convaincre au-delà des démonstrations. On y suit aussi les usages grand public qui commencent réellement à s'installer, loin des annonces qui ne débouchent sur rien.",
  },
  {
    title: "Intelligence artificielle",
    body: "L'IA est partout, mais rarement expliquée simplement. Cette catégorie couvre ses usages concrets — au travail, dans la création, dans la recherche — ainsi que les questions qu'elle soulève : éthique, régulation, impact sur l'emploi, fiabilité réelle des outils. L'objectif est de séparer ce qui fonctionne vraiment aujourd'hui de ce qui relève encore de la promesse marketing. On y couvre aussi bien les grandes annonces des laboratoires de recherche que les usages plus discrets, déjà intégrés dans des outils que vous utilisez peut-être sans le savoir.",
  },
  {
    title: "LLM & IA générative",
    body: "Les grands modèles de langage (LLM) et les outils d'IA générative — chatbots, générateurs d'images, assistants de code — ont leur propre catégorie tant leur évolution est rapide. On y compare les modèles entre eux, on explique comment les utiliser efficacement, cas d'usage concrets à l'appui, et on prend le temps de signaler leurs limites autant que leurs progrès. On y trouve aussi des guides pratiques pour rédiger de meilleurs prompts, automatiser des tâches répétitives, ou simplement comprendre ce qui se cache derrière l'outil que vous utilisez peut-être déjà.",
  },
  {
    title: "Robots & robotique",
    body: "Robots domestiques, robots industriels, humanoïdes : la robotique avance vite, portée par les progrès de l'IA et de la miniaturisation. On y suit les annonces qui comptent réellement, les usages déjà concrets — logistique, santé, agriculture — et ceux qui restent, pour l'instant, au stade de démonstration. On s'intéresse en particulier à la frontière, parfois floue, entre un prototype spectaculaire en vidéo et un produit réellement utilisable au quotidien.",
  },
  {
    title: "Drones",
    body: "Drones grand public, drones professionnels (agriculture, BTP, inspection, cinéma), drone racing, cadre réglementaire : cette catégorie suit un secteur à la croisée de la robotique et de l'aérien. On y teste le matériel destiné aux particuliers — photo, vidéo, loisir — mais aussi les usages professionnels qui se généralisent, souvent moins spectaculaires que les vidéos qui circulent sur les réseaux mais bien plus significatifs pour l'avenir du secteur. On y suit aussi les évolutions réglementaires, qui changent régulièrement ce qu'il est permis de faire voler, où, et sous quelles conditions — un point souvent négligé mais essentiel avant tout achat.",
  },
  {
    title: "Crypto & Web3",
    body: "Cryptomonnaies, blockchain, finance décentralisée : cette catégorie décrypte un secteur volatile et souvent mal expliqué. Notre approche est pédagogique et prudente — on explique comment fonctionne une technologie ou un projet, sans jamais recommander un investissement. On y couvre aussi bien les projets déjà établis que les tendances émergentes, avec un regard critique sur les promesses non tenues qui ont marqué ce secteur. Les contenus de cette catégorie sont informatifs, pas des conseils financiers : à vous de faire vos propres recherches avant toute décision, et de ne jamais investir plus que ce que vous pouvez vous permettre de perdre.",
  },
];

export default function HomePage() {
  const posts = getAllPosts();

  return (
    <>
      <section className="home-hero">
        <h1>Techno Play — la tech, les jeux, l&apos;IA et la crypto expliqués simplement</h1>
        <p className="lead">
          Techno Play est un média indépendant qui décrypte la technologie
          sous toutes ses formes : gadgets, jeux vidéo, réalité virtuelle,
          intelligence artificielle, robotique, drones et crypto-monnaies.
          Notre objectif est simple : vous aider à
          comprendre ce qui compte vraiment, sans jargon inutile et sans
          emballement artificiel autour de la moindre annonce. Que vous
          soyez simplement curieux, joueur passionné, développeur,
          investisseur ou juste quelqu&apos;un qui essaie de suivre le
          rythme d&apos;un secteur qui change chaque semaine, vous
          trouverez ici des articles pensés pour être utiles en premier
          lieu — pas pour remplir une grille de mots-clés ni gonfler
          artificiellement une audience. Chaque semaine apporte son lot
          d&apos;annonces, de lancements et de promesses ; notre travail
          consiste à trier ce qui mérite votre attention de ce qui
          n&apos;est que du bruit.
        </p>
      </section>

      <section className="home-section">
        <h2>Notre promesse éditoriale</h2>
        <p>
          Chaque sujet traité sur Techno Play suit la même règle : vérifier
          avant de publier. Quand un chiffre, un test ou une affirmation
          technique est cité, il est vérifié — jamais inventé, jamais repris
          tel quel d&apos;un communiqué de presse sans recul critique. Quand
          nous testons un produit, nous listons aussi bien ce qui fonctionne
          que ce qui déçoit, plutôt que de nous limiter aux points positifs.
          La ligne éditoriale n&apos;est influencée par aucun annonceur, et
          tout contenu sponsorisé serait clairement identifié comme tel
          s&apos;il existait. Une erreur signalée est corrigée ouvertement,
          plutôt que laissée silencieusement en ligne. Vous pouvez consulter
          la page <a href="/a-propos/">à propos</a> pour savoir qui écrit et
          pourquoi, ou nous <a href="/contact/">contacter directement</a>{" "}
          pour signaler une erreur, proposer un sujet ou simplement dire
          bonjour.
        </p>
      </section>

      <section className="home-section">
        <h2>Ce que vous trouverez ici</h2>
        <p>
          Le site est organisé autour de huit grands thèmes qui se recoupent
          souvent — l&apos;intelligence artificielle infuse aujourd&apos;hui
          les jeux vidéo autant que la robotique, et la frontière entre tech
          et crypto n&apos;a jamais été aussi fine. Chaque catégorie est
          pensée aussi bien pour un lecteur pressé, qui veut l&apos;essentiel
          en quelques minutes, que pour un lecteur qui veut aller au fond
          des choses.
        </p>

        <div className="category-grid">
          {CATEGORIES.map((cat) => (
            <article className="category-card" key={cat.title}>
              <h3>{cat.title}</h3>
              <p>{cat.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="home-section">
        <p>
          Techno Play est un projet jeune : nous préférons publier moins
          souvent mais avec plus de rigueur plutôt que de multiplier les
          articles sans valeur ajoutée. Chaque article passe par une phase
          de vérification avant sa mise en ligne, ce qui explique pourquoi
          le rythme de publication reste volontairement mesuré, au moins
          dans un premier temps. Retrouvez les derniers articles juste en
          dessous, mis à jour au fil de l&apos;actualité et de nos tests.
          Pour ne rien manquer, suivez-nous sur nos réseaux (liens en pied
          de page), ou écrivez-nous directement via la page{" "}
          <a href="/contact/">contact</a> — vos retours, corrections et
          suggestions de sujets sont toujours les bienvenus, et façonnent
          directement les prochains articles publiés.
        </p>
      </section>

      <section className="home-section">
        <h2>Derniers articles</h2>
        {posts.length === 0 ? (
          <p className="empty-state">Aucun article publié pour l&apos;instant.</p>
        ) : (
          <ul className="post-list">
            {posts.map((post) => (
              <li key={post.slug}>
                <a href={`/${post.slug}/`}>
                  <h3>{post.title}</h3>
                </a>
                <p className="post-meta">
                  <time dateTime={post.date}>{post.date}</time>
                  {post.author ? ` · ${post.author}` : ""}
                </p>
                <p className="post-description">{post.description}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
